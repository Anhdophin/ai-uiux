# Mandatory App Scaffold Rules

## 1. Architecture first
- Domain-first, feature-second, UI-last.
- Engine layer là bắt buộc cho flow logic, mapping logic, AI logic, audit logic.
- Integration layer phải nằm ngoài domain để tránh coupling ngầm.

## 2. Source of truth
- `docs/product/*.md` là nguồn sự thật về sản phẩm.
- `schemas/` là nguồn sự thật về cấu trúc dữ liệu.
- `src/backend/app/engine/` là nguồn sự thật về orchestration.

## 3. Separation rules
- Domain model không được phụ thuộc trực tiếp vào UI.
- UI component không được gọi AI provider trực tiếp.
- API route không chứa business logic dài.
- Prompt text phải tập trung ở 1 nơi có version.

## 4. Scalability rules
- Mỗi domain phải có `models`, `services`, `validators` hoặc tương đương khi đủ lớn.
- Mọi enum hoặc constant dùng nhiều nơi phải kéo vào `core/constants` hoặc schema chung.
- Data seed phải tách khỏi code.

## 5. Flexibility rules
- Dùng interface / schema / DTO rõ ràng để có thể đổi frontend, đổi AI provider, đổi storage về sau.
- Mọi engine nhận input chuẩn hóa và trả output chuẩn hóa.
- Tất cả prompt mode phải khai báo tường minh, không hardcode rải rác.

## 6. Comment rules
- Mỗi file đầu tiên phải có comment mô tả mục đích file.
- Các điểm quyết định kiến trúc phải có comment giải thích "tại sao", không chỉ "làm gì".
