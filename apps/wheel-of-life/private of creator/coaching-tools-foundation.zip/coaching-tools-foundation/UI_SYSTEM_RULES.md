# UI System Rules

## Design intention
UI phải tạo cảm giác: bình tĩnh, có cấu trúc, khám phá dần, không dồn ép.

## Core principles
- Icon-first, card-first, reveal-progressively.
- Tránh màn hình đầu quá tải.
- Mỗi hành động chính phải tương ứng với một node hoặc trạng thái có ý nghĩa domain.
- Cho phép user quay lui mà không mất ngữ cảnh.

## Visual rules
- Dùng token cho spacing, radius, color, shadow.
- Typography rõ phân cấp, tránh quá nhiều style trang trí.
- Trạng thái active / selected / expanded phải dễ đọc.
- Mobile trước, desktop mở rộng sau.

## Interaction rules
- Một bước chỉ mở số lựa chọn vừa đủ.
- Khi user chọn node, phải hiện trail ngữ cảnh.
- AI panel là lớp hỗ trợ, không chiếm toàn bộ trải nghiệm.
- Wheel view chỉ hiện sau khi đủ dữ liệu tối thiểu.

## Component layers
- Base: button, chip, tag, input, card, panel.
- Composite: step header, context trail, keyword group, reflection sheet.
- Domain: wheel board, AI deepen panel, keyword branch explorer.

## Naming rules
- CSS dùng class có prefix `ct-`.
- JS selector ưu tiên `data-*` cho hook hành vi.
- Component phải được đặt tên theo vai trò, không theo màu sắc hoặc vị trí ngẫu nhiên.
