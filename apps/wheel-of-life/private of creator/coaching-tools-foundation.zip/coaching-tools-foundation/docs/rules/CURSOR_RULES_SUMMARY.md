# Cursor Rules Summary

Dùng file này làm mục lục ngắn để AI biết phải bám theo rule nào.
- `../../AI_AGENT_ENFORCER.md`
- `../../MANDATORY_APP_SCAFFOLD_RULES.md`
- `../../UI_SYSTEM_RULES.md`
- `../../DATA_AND_AI_RULES.md`
