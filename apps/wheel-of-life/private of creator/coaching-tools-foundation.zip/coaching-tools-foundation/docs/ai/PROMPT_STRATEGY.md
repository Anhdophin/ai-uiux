# Prompt Strategy

## Goal
Biến context rời rạc thành context snapshot gọn, rõ, có thể kiểm soát.

## Prompt sections
1. Persona summary
2. Current feeling summary
3. Selected keyword trail
4. Reflection snippets
5. Wheel snapshot if any
6. Current AI mode
7. Safety boundary reminder

## Note
Prompt text phải versioned và tách khỏi UI.
