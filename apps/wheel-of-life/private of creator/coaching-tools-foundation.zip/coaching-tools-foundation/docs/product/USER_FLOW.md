# User Flow

## Phase 1: Context Setup
User chọn nhóm tuổi, giới tính, trạng thái học / đi làm / chuyển nghề / kinh doanh.

## Phase 2: Feeling Entry
User chọn cảm nhận đang nổi bật nhất và mức độ ảnh hưởng.

## Phase 3: Keyword Journey
Hệ thống mở từng lớp từ khóa. User chọn một hoặc nhiều nhánh liên quan.

## Phase 4: Reflection Capture
User ghi chú hoặc chọn câu mô tả sát với mình.

## Phase 5: Wheel Mapping
Hệ thống map các lựa chọn đã có vào các life area và cho user review.

## Phase 6: AI Deepening
AI dùng context snapshot để hỏi sâu, phản chiếu, gợi mở thêm hướng hiểu.

## Phase 7: Save / Continue
Lưu hành trình hiện tại để user quay lại tiếp tục.
