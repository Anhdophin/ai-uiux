# Domain Model

## 1. Identity Context Domain
Dữ liệu nền về tuổi, giới tính, giai đoạn sống, giai đoạn nghề, mục tiêu quan tâm.

## 2. Feeling Entry Domain
Điểm vào từ cảm nhận hiện tại: mơ hồ, áp lực, chán, stuck, muốn đổi, lo tương lai...

## 3. Keyword Exploration Domain
Cây từ khóa nhiều lớp, quan hệ cha-con, quan hệ liên kết chéo, persona weighting, wheel mapping hints.

## 4. Reflection Domain
Nơi user ghi lại suy nghĩ, ví dụ, tự chấm mức ảnh hưởng, note cá nhân.

## 5. Wheel of Life Domain
Các life area, sub-area, evidence nodes, score tạm tính, imbalance detection.

## 6. AI Coaching Domain
Prompt builder, AI mode, response validator, session turn history.

## 7. Audit Domain
Coverage, contradiction, orphan node, stale mapping, prompt traceability.

## Domain relation summary
Identity Context -> Feeling Entry -> Keyword Exploration -> Reflection -> Wheel of Life -> AI Coaching
Audit theo dõi toàn bộ chuỗi trên.
