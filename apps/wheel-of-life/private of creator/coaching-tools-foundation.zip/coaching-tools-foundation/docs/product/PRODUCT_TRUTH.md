# Product Truth

## App này là gì
Một coaching tools / self-reflection tools dạng mở từ khóa từng bước, giúp user đi từ cảm nhận hiện tại đến việc nhận diện vấn đề, hiểu mối liên kết giữa các khía cạnh cuộc sống, và dần map sang một mô hình wheel of life có ngữ cảnh thực tế.

## App này không phải là gì
- Không phải công cụ chẩn đoán tâm lý.
- Không phải chatbot tán gẫu tự do.
- Không phải bài trắc nghiệm một lần rồi xong.
- Không phải công cụ ép user đi theo một chuẩn sống duy nhất.

## User value
- Nhận diện bản thân rõ hơn.
- Tự nhìn thấy vòng lặp vấn đề.
- Lưu được dữ liệu phát triển bản thân dài hạn.
- Có thể dùng AI để khai vấn sâu hơn mà không mất ngữ cảnh.

## Core product units
- Persona context
- Feeling entry
- Keyword node
- Reflection entry
- Wheel area
- AI assist turn
- Audit trace

## Product law
1. Bắt đầu từ thực tại cảm nhận.
2. Mở dần từng lớp.
3. Mọi kết luận đều phải truy về ngữ cảnh đã chọn.
4. Không flatten nuance thành lời khuyên chung chung.
