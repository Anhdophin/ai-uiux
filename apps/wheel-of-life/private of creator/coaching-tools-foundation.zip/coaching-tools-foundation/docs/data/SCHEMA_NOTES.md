# Schema Notes

## Entities ưu tiên có sớm
- UserContextProfile
- FeelingSelection
- KeywordNode
- ReflectionEntry
- WheelState
- AISessionTurn

## Mapping notes
- KeywordNode phải có `life_area_mappings`
- KeywordNode nên có `related_node_ids`
- WheelState nên có `evidence_node_ids`
