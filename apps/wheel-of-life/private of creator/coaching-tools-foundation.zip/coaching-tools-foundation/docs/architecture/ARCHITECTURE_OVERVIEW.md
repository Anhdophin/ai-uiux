# Architecture Overview

## High-level shape
- Frontend: trình bày card journey, trail, reflection, wheel preview.
- Backend: API + domain services + engine + AI boundary.
- Data: seed JSON / schemas / storage adapter.
- AI layer: prompt builder -> provider adapter -> validator.

## Golden rule
Không có tuyến nào được đi thẳng từ UI tới AI provider.

## Request flow
User interaction -> API route -> service -> engine -> validated output -> UI update
