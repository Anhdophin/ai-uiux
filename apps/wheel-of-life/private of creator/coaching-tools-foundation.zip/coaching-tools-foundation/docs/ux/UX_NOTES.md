# UX Notes

## Trải nghiệm mong muốn
- Không làm user thấy như bị kiểm tra.
- Không ép user trả lời quá nhiều ở bước đầu.
- Cho user cảm giác đang mở bản đồ về chính mình.

## Các màn hình nên có
- Home / entry
- Context setup
- Feeling selection
- Keyword journey
- Reflection panel
- Wheel preview
- AI deepen panel
- Saved sessions
