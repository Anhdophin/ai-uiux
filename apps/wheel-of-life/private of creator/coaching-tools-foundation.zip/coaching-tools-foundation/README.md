# Coaching Tools Foundation Scaffold

Bộ khung nền cho app coaching / self-reflection dạng mở từ khóa từng bước.

## Mục tiêu
- Khóa kiến trúc ngay từ đầu để AI không kéo code đi lệch.
- Tách rõ domain, engine, UI, data, AI boundary.
- Có scaffold đủ chặt để audit, nhưng đủ mềm để scale.

## Triết lý
1. Bắt đầu từ cảm nhận thật.
2. Mở ngữ cảnh dần theo từng lớp.
3. Không để AI suy diễn vượt ngữ cảnh.
4. Raw data, derived data, AI data phải tách riêng.
5. Mọi mapping phải truy vết được.

## Cấu trúc chính
- `docs/` Tài liệu khóa tư duy và luật nền.
- `src/backend/` Backend scaffold (FastAPI) + domain + engine.
- `src/frontend/` Frontend scaffold HTML/CSS/JS theo card + keyword journey.
- `tests/` chỗ để đặt unit / integration / audit tests.

## Chạy demo nền
### Backend
```bash
cd src/backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Frontend
Mở file `src/frontend/index.html` trực tiếp hoặc serve bằng local server.

## Ghi chú quan trọng
- Đây là scaffold nền, chưa phải app hoàn chỉnh.
- Mọi AI agent hoặc coder sau này phải đọc toàn bộ file trong `docs/rules/` và 4 file gốc trong `docs/product/` trước khi sửa code.
