# Data and AI Rules

## Data classes
### Raw data
Dữ liệu do user tạo trực tiếp.

### Derived data
Dữ liệu do engine suy ra từ raw data.

### AI data
Dữ liệu do AI sinh ra từ context đã chuẩn hóa.

> Ba lớp này không được lưu lẫn lộn trong cùng một object gốc mà không đánh dấu loại.

## Persistence rules
- Mọi record persistent phải có: `id`, `created_at`, `updated_at`, `version`.
- Nếu record được AI sinh: phải có `source_type = ai` và `prompt_mode`.
- Nếu record do engine suy ra: phải có `source_type = derived`.
- Nếu record đến từ user: phải có `source_type = user`.

## Schema rules
- Không được dùng JSON blob mơ hồ khi đã biết cấu trúc.
- Mọi schema mới phải có field mô tả ngắn hoặc comment trong file schema.
- Mapping phải có khả năng reverse lookup.

## AI rules
- AI chỉ nhận context snapshot đã được app chuẩn hóa.
- AI output phải validate theo schema trước khi đưa lên UI.
- AI không được overwrite raw user input.
- AI insight phải trỏ được về node / reflection / context liên quan.

## Prompt versioning
- Prompt mode phải có version.
- Khi đổi logic prompt, tăng version và ghi changelog ngắn.
