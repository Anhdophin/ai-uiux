# Storage Layer Notes

- Khi còn ở phase scaffold, có thể dùng JSON hoặc SQLite.
- Khi mở rộng, storage adapter phải giữ interface ổn định để đổi backend dễ hơn.
- Không để domain service phụ thuộc thẳng vào engine của DB cụ thể.
