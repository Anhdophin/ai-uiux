"""Project-wide constants.

Keep shared strings here to avoid fragile magic values.
"""

AI_MODES = {
    "clarify_mode",
    "deepen_mode",
    "pattern_mode",
    "wheel_interpretation_mode",
    "suggest_direction_mode",
}
