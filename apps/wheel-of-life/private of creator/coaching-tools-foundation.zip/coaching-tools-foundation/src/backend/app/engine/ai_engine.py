"""AI engine scaffold.

This file shows the boundary pattern:
- receive normalized snapshot
- generate structured output
- return validated response

Real provider integration should live behind a provider adapter.
"""

from app.schemas.ai import AIDeepenResponse


def generate_demo_ai_response(snapshot: dict) -> AIDeepenResponse:
    feeling_id = snapshot["feeling"]["feeling_id"]
    selected_keywords = snapshot.get("selected_keywords", [])
    keyword_hint = ", ".join(selected_keywords) if selected_keywords else "chưa có nhiều nhánh cụ thể"

    summary = (
        f"User đang đi từ cảm nhận '{feeling_id}' và đã chạm tới các từ khóa: {keyword_hint}. "
        "Hệ thống nên phản chiếu ngắn, rồi mở thêm hướng đi tiếp thay vì kết luận mạnh."
    )

    return AIDeepenResponse(
        summary=summary,
        possible_patterns=[
            "Có thể đây là vấn đề định hướng chứ chưa hẳn là vấn đề năng lực.",
            "Cảm nhận hiện tại có thể liên quan đồng thời tới career và inner system.",
            "Nếu trạng thái này kéo dài, nên truy thêm các node về môi trường và năng lượng."
        ],
        follow_up_questions=[
            "Điều gì làm anh thấy nặng nhất: thiếu hướng, thiếu lực, hay thiếu đường đi cụ thể?",
            "Trong 3 tháng gần đây, trạng thái này tăng lên vì công việc, tài chính, hay bản thân?",
            "Có nhánh nào anh đã thử thay đổi nhưng vẫn lặp lại không?"
        ],
        next_keyword_paths=[
            "không thấy tương lai",
            "không rõ mình mạnh gì",
            "muốn đổi nhưng sợ reset"
        ],
        confidence_note="Đây là gợi mở sơ bộ từ context hiện tại, chưa phải kết luận cuối cùng."
    )
