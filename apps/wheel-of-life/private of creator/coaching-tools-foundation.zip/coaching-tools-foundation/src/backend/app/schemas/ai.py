"""Schemas for AI requests and validated outputs.

Even demo responses should follow a predictable contract.
"""

from pydantic import BaseModel, Field

from app.schemas.context import ContextProfileIn
from app.schemas.feeling import FeelingSelectionIn


class AIDeepenRequest(BaseModel):
    mode: str = Field(..., examples=["clarify_mode", "deepen_mode", "pattern_mode"])
    context_profile: ContextProfileIn
    feeling: FeelingSelectionIn
    selected_keywords: list[str] = Field(default_factory=list)
    reflection_snippet: str | None = None


class AIDeepenResponse(BaseModel):
    summary: str
    possible_patterns: list[str]
    follow_up_questions: list[str]
    next_keyword_paths: list[str]
    confidence_note: str
