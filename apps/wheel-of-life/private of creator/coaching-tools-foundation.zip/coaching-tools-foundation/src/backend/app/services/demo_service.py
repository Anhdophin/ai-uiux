"""Demo service to normalize request into a small context snapshot.

In real implementation, this service should combine storage data,
selected nodes, previous journey, and wheel snapshot.
"""

from app.schemas.ai import AIDeepenRequest


def build_demo_snapshot(payload: AIDeepenRequest) -> dict:
    return {
        "mode": payload.mode,
        "persona": payload.context_profile.model_dump(),
        "feeling": payload.feeling.model_dump(),
        "selected_keywords": payload.selected_keywords,
        "reflection_snippet": payload.reflection_snippet,
    }
