"""API routes for scaffold demo.

Routes should stay thin. They call services / engines only.
"""

from fastapi import APIRouter

from app.schemas.context import ContextProfileIn
from app.schemas.feeling import FeelingSelectionIn
from app.schemas.ai import AIDeepenRequest, AIDeepenResponse
from app.services.demo_service import build_demo_snapshot
from app.engine.ai_engine import generate_demo_ai_response

router = APIRouter(prefix="/api")


@router.post("/context/preview")
def preview_context(payload: ContextProfileIn) -> dict:
    """Preview normalized context without persisting yet."""
    return {"normalized_context": payload.model_dump()}


@router.post("/feeling/preview")
def preview_feeling(payload: FeelingSelectionIn) -> dict:
    return {"normalized_feeling": payload.model_dump()}


@router.post("/ai/deepen", response_model=AIDeepenResponse)
def ai_deepen(payload: AIDeepenRequest) -> AIDeepenResponse:
    snapshot = build_demo_snapshot(payload)
    return generate_demo_ai_response(snapshot)
