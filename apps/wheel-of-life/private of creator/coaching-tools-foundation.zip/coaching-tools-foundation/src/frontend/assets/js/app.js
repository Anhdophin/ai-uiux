// App bootstrap and interaction wiring.
// Keep this file focused on event orchestration, not heavy domain logic.
(function () {
  const { renderFeelings, renderKeywords, updateTrail, renderAIOutput } = window.ctUI;

  function bindContextForm() {
    const form = document.querySelector('[data-role="context-form"]');
    if (!form) return;

    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      window.ctState.context = Object.fromEntries(formData.entries());
      updateTrail();
    });
  }

  function bindFeelingSelection() {
    document.addEventListener('click', (event) => {
      const button = event.target.closest('[data-role="feeling-card"]');
      if (!button) return;

      document.querySelectorAll('[data-role="feeling-card"]').forEach((card) => {
        card.classList.remove('is-selected');
      });

      button.classList.add('is-selected');
      window.ctState.selectedFeeling = button.dataset.feelingId;
      window.ctState.selectedKeywords = [];
      renderKeywords(window.ctState.selectedFeeling);
      updateTrail();
    });
  }

  function bindKeywordSelection() {
    document.addEventListener('click', (event) => {
      const button = event.target.closest('[data-role="keyword-pill"]');
      if (!button) return;

      const keyword = button.dataset.keyword;
      const exists = window.ctState.selectedKeywords.includes(keyword);
      window.ctState.selectedKeywords = exists
        ? window.ctState.selectedKeywords.filter((item) => item !== keyword)
        : [...window.ctState.selectedKeywords, keyword];

      button.classList.toggle('is-selected', !exists);
    });
  }

  function bindReflection() {
    const input = document.querySelector('[data-role="reflection-input"]');
    const saveButton = document.querySelector('[data-role="save-reflection"]');
    if (!input || !saveButton) return;

    saveButton.addEventListener('click', () => {
      window.ctState.reflection = input.value.trim();
    });
  }

  async function requestAIDeepening() {
    const endpoint = 'http://127.0.0.1:8000/api/ai/deepen';
    const payload = {
      mode: 'deepen_mode',
      context_profile: {
        age_range: window.ctState.context?.age_range || '25-29',
        gender: window.ctState.context?.gender || 'male',
        life_stage: window.ctState.context?.life_stage || 'working',
        career_stage: window.ctState.context?.career_stage || 'early',
        goals: [],
        concerns: []
      },
      feeling: {
        feeling_id: window.ctState.selectedFeeling || 'unclear_direction',
        intensity: 3,
        frequency: 'often',
        note: null
      },
      selected_keywords: window.ctState.selectedKeywords,
      reflection_snippet: window.ctState.reflection || null
    };

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      renderAIOutput(data);
    } catch (error) {
      renderAIOutput({
        summary: 'Chưa kết nối được backend AI scaffold.',
        possible_patterns: ['Hãy chạy backend FastAPI trước.'],
        follow_up_questions: ['Backend đã chạy tại port 8000 chưa?'],
        next_keyword_paths: [],
        confidence_note: 'Lỗi kết nối local.'
      });
      console.error(error);
    }
  }

  function bindAIButton() {
    const button = document.querySelector('[data-role="ask-ai"]');
    if (!button) return;
    button.addEventListener('click', requestAIDeepening);
  }

  renderFeelings();
  bindContextForm();
  bindFeelingSelection();
  bindKeywordSelection();
  bindReflection();
  bindAIButton();
  updateTrail();
})();
