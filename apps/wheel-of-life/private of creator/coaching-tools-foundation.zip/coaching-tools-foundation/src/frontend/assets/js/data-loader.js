// Seed data loader.
// In larger builds, this can be replaced by API fetch or versioned content packages.
window.ctSeed = {
  feelings: [
    { id: 'unclear_direction', title: 'Mơ hồ hướng đi', subtitle: 'Không rõ mình nên đi đâu tiếp.' },
    { id: 'pressure', title: 'Áp lực', subtitle: 'Cảm giác bị nén bởi nhiều thứ cùng lúc.' },
    { id: 'stuck', title: 'Bị kẹt', subtitle: 'Đang đứng yên dù vẫn cố gắng.' },
    { id: 'want_change', title: 'Muốn đổi', subtitle: 'Muốn rẽ hướng nhưng còn sợ.' }
  ],
  keywordsByFeeling: {
    unclear_direction: ['không thấy tương lai', 'không rõ mình mạnh gì', 'không có roadmap'],
    pressure: ['áp lực tài chính', 'áp lực kỳ vọng', 'quá nhiều vai trò'],
    stuck: ['làm lâu nhưng không tiến', 'thiếu động lực', 'môi trường không kéo mình lên'],
    want_change: ['muốn đổi nghề', 'muốn kinh doanh', 'sợ reset từ đầu']
  }
};
