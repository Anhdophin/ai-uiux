// UI rendering helpers.
// Keep DOM creation logic grouped here so app logic stays smaller.
(function () {
  function renderFeelings() {
    const grid = document.querySelector('[data-role="feeling-grid"]');
    if (!grid) return;

    grid.innerHTML = window.ctSeed.feelings
      .map(
        (item) => `
          <button class="ct-choice-card" data-role="feeling-card" data-feeling-id="${item.id}">
            <strong>${item.title}</strong>
            <span class="ct-muted">${item.subtitle}</span>
          </button>
        `
      )
      .join('');
  }

  function renderKeywords(feelingId) {
    const board = document.querySelector('[data-role="keyword-board"]');
    if (!board) return;

    const list = window.ctSeed.keywordsByFeeling[feelingId] || [];
    board.innerHTML = list
      .map(
        (keyword) =>
          `<button class="ct-keyword-pill" data-role="keyword-pill" data-keyword="${keyword}">${keyword}</button>`
      )
      .join('');
  }

  function updateTrail() {
    const trail = document.querySelector('[data-role="context-trail"]');
    if (!trail) return;

    const parts = [];
    if (window.ctState.context?.age_range) parts.push(window.ctState.context.age_range);
    if (window.ctState.context?.life_stage) parts.push(window.ctState.context.life_stage);
    if (window.ctState.selectedFeeling) parts.push(window.ctState.selectedFeeling);

    trail.innerHTML = parts.length
      ? parts.map((part) => `<span class="ct-chip">${part}</span>`).join('')
      : '<span class="ct-chip">Chưa có context</span>';
  }

  function renderAIOutput(payload) {
    const box = document.querySelector('[data-role="ai-output"]');
    if (!box) return;

    box.innerHTML = `
      <strong>Tóm tắt</strong>
      <p>${payload.summary}</p>
      <strong>Khả năng đang diễn ra</strong>
      <ul>${payload.possible_patterns.map((item) => `<li>${item}</li>`).join('')}</ul>
      <strong>Câu hỏi tiếp</strong>
      <ul>${payload.follow_up_questions.map((item) => `<li>${item}</li>`).join('')}</ul>
    `;
  }

  window.ctUI = {
    renderFeelings,
    renderKeywords,
    updateTrail,
    renderAIOutput,
  };
})();
