// Central in-memory state for scaffold demo.
// Later this can move to a formal store without changing UI contracts.
window.ctState = {
  context: null,
  selectedFeeling: null,
  selectedKeywords: [],
  reflection: "",
};
