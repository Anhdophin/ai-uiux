# Frontend Data Notes

- Seed nhỏ chỉ để kiểm tra flow.
- Khi nội dung lớn dần, nên tách content package có version.
- Không hardcode hết keyword tree trong một file JS lớn.
