# Test Notes

Các nhóm test nên có về sau:
- unit: schema, mapping, validators
- integration: route -> service -> engine
- flow: user journey chính
- audit: orphan node, contradictory mapping, missing reverse lookup
