# AI Agent Enforcer

> File này dành cho AI agent, coding assistant, và bất kỳ công cụ sinh code nào làm việc trong project này.

## Mandatory reading order
AI phải đọc theo thứ tự sau trước khi tạo hoặc sửa code:
1. `docs/product/PRODUCT_TRUTH.md`
2. `docs/product/DOMAIN_MODEL.md`
3. `docs/product/USER_FLOW.md`
4. `docs/product/AI_BOUNDARY.md`
5. `MANDATORY_APP_SCAFFOLD_RULES.md`
6. `UI_SYSTEM_RULES.md`
7. `DATA_AND_AI_RULES.md`

## Non-negotiable enforcement
- Không được viết logic business vào UI component thuần trình bày.
- Không được tạo file lạc chỗ ngoài cấu trúc scaffold nếu chưa có lý do rõ trong docs.
- Không được trộn raw data, derived data, AI data.
- Không được cho AI trả lời trực tiếp từ user input mà không đi qua context builder / prompt builder.
- Không được đổi tên entity, schema, route, folder một cách ngẫu hứng.
- Không được phá backward compatibility của schema nếu chưa version hóa.
- Không được map keyword vào wheel area mà không có trace link.
- Không được để orphan node, dead branch, hoặc mapping một chiều không truy ngược được.

## Required behavior when editing
- Nếu thêm domain mới: cập nhật `DOMAIN_MODEL.md`.
- Nếu thêm flow mới: cập nhật `USER_FLOW.md`.
- Nếu thêm prompt mode hoặc đổi boundary AI: cập nhật `AI_BOUNDARY.md`.
- Nếu thêm schema hoặc đổi field persistent: cập nhật `DATA_AND_AI_RULES.md` và folder `schemas/`.
- Nếu thêm UI pattern lớn: cập nhật `UI_SYSTEM_RULES.md`.

## Output discipline
- Ưu tiên diff nhỏ, rõ, có comment đầu file.
- Không tạo code “đẹp bề ngoài nhưng mơ hồ kiến trúc”.
- Nếu chưa chắc về domain, phải giữ nguyên code và ghi TODO rõ ràng.
